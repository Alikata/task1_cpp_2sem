#include <iostream>
#include "string_view.h"

int main()
{
    string_view view1;
    return 0;
}
